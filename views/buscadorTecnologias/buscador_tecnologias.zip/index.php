    <?php
        include "php/conexion.php";
        error_reporting(E_ERROR);

    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Somos la Agencia Mexicana de Vinculación Tecnológica, una asociación civil sin fines de lucro dedicada a promover, gestionar y capacitar la vinculación entre empresas y universidades.">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PACT</title>
            <!--Import Google Icon Font-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<!-- Compiled and minified JavaScript -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script> 

<!-- Compiled and minified CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

<!--Import jQuery before materialize.js-->
        <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
        
        <link rel="stylesheet" href="../../public/css/style.css">


       <!--<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">-->

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <title>
        </title>
    </head>
    <body>
    <div class="navbar-fixed">
        <nav>
            <div class="nav-wrapper container">
                <a class="brand-logo center">Tecnologías</a>
                <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            </div>
        </nav>
    </div>

    <?php require '../sidenav.php'; ?> 

        <div class="section wrapper">
            <div class="content_container">

            <div id="talentos">
                <section class="table_container">
                    <table id="" class="table sticky bold">
                <thead>
                <tr class="tr">
                    <th>Nombre de la tecnología</th>
                    <th>Tipo tecnología</th>
                    <th>Verbo</th>
                    <th>Descripcion</th>
                    
                </tr>
                </thead>

            <?php
                $query = mysqli_query($connection, "SELECT * FROM manera_solucionar ms
                    INNER JOIN  tecnologia tec ON ms.tecnologia_idtecnologia = tec.idtecnologia
                    INNER JOIN tipo_tecnologia tt ON ms.tipo_tecnologia_idtipo_tecnologia = tt.idtipo_tecnologia
                    INNER JOIN verbo_solucion vs ON ms.verbo_solucion_idverbo_solucion = vs.idverbo_solucion

                    ");

                $result = mysqli_num_rows($query);

                if($result > 0){
                    while($data = mysqli_fetch_array($query)){
            ?>

                <tr>
                    <td id="grado"> <?php echo $data["nombre"]?></td>
                    <td id="grado"> <?php echo $data["tipo_tecnologia"]?></td>
                    <td id="titulo"> <?php echo $data["verbo_solucion"]?></td>
                    <td id="escuela"> <?php echo $data["complemento"]?></td>
                </tr>

            <?php
                    }
                }

                 if ($result == 0) {
                    echo $message;
                    }
            ?>
            </table>
            </section>

            </div>
            </div>
        </div>

        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    </body>
    </html>