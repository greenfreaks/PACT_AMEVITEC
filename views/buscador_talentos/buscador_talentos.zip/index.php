    <?php
        include "php/conexion.php";
        error_reporting(E_ERROR);

    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Somos la Agencia Mexicana de Vinculación Tecnológica, una asociación civil sin fines de lucro dedicada a promover, gestionar y capacitar la vinculación entre empresas y universidades.">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PACT</title>
            <!--Import Google Icon Font-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<!-- Compiled and minified JavaScript -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script> 

<!-- Compiled and minified CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

<!--Import jQuery before materialize.js-->
        <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
        
        <link rel="stylesheet" href="../../public/css/style.css">


       <!--<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">-->

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <title>
        </title>
    </head>
    <body>
    <div class="navbar-fixed">
        <nav>
            <div class="nav-wrapper container">
                <a class="brand-logo center">Talentos</a>
                <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            </div>
        </nav>
    </div>

    <?php require '../sidenav.php'; ?> 

        <div class="section wrapper">
            <div class="content_container">

        <form method="POST" class="filtros">
            <p>Utiliza los filtros de búsqueda para encontrar lo que necesitas.</p>
            <div class="searcher">
                <input type="text" placeholder="Escribe aquí lo que estés buscando..." name="searcher" value="<?php echo $_POST["searcher"] ?>">
            </div>

            <div class="funcion_filter">
                <h6>Seleccione una función.</h6>
                <select name="funcion" id="" class="browser-default">
                    <?php if($_POST['funcion'] !=""){?>
                        <option value="<?php echo $_POST['funcion'];?>"><?php echo $_POST['funcion'];?></option>
                    <?php } ?>
                        
                    <option value="">Todos</option>

                    <?php include "php/llenado_funcion.php" ?>

                </select>
            </div> <br>

                <button class="btn" type="submit">Buscar</button>
                <a href="index.php" class="bold">Limpiar filtros</a>

                <?php 
                    include "php/filtros.php"
                ?>
            </form>

            <div id="talentos">
                <section class="table_container">
                    <table id="" class="table sticky bold">
                <thead>
                <tr class="tr">
                    <th>Grado Académico</th>
                    <th>Título Obtenido</th>
                    <th>Escuela</th>
                    <th>Organización a la que pertenece actualmente</th>
                    <th>Función dentro de la organización</th>
                    <th>Campo del conocimiento en el que ha desarrollado su experiencia</th>
                    <th>Disciplina</th>
                    <th>Subdisciplina</th>
                    <th>Solicitar</th>
                    
                </tr>
                </thead>

            <?php
                $query = mysqli_query($connection, "SELECT * FROM perfil_academico pa
                    INNER JOIN usuario_general ug ON pa.usuario_general_idusuario_general = ug.idusuario_general
                    INNER JOIN grado_academico ga ON pa.grado_academico_idgrado_academico = ga.idgrado_academico
                    INNER JOIN organizacion org ON pa.organizacion_actual = org.idorganizacion
                    INNER JOIN funcion_academico fa ON pa.funcion_academico_idfuncion_academico = fa.idfuncion_academico
                    INNER JOIN subdisciplina sub ON pa.subdisciplina_idsubdisciplina = sub.idsubdisciplina
                    INNER JOIN disciplina dis ON sub.disciplina_iddisciplina = dis.iddisciplina
                    INNER JOIN campo_conocimiento camp ON dis.campo_conocimiento_idcampo_conocimiento = camp.idcampo_conocimiento
                    INNER JOIN perfil_academico_has_actividad_experiencia exp ON exp.perfil_academico_idperfil_academico $where LIMIT 10
                    
                    ");

                $result = mysqli_num_rows($query);

                if($result > 0){
                    while($data = mysqli_fetch_array($query)){
            ?>

                <tr>
                    <td id="grado"> <?php echo $data["grado_academico"]?></td>
                    <td id="titulo"> <?php echo $data["titulo_obtenido"]?></td>
                    <td id="escuela"> <?php echo $data["escuela"]?></td>
                    <td id="organizacion"> <?php echo $data["organizacion"]?></td>
                    <td id="funcion"> <?php echo $data["funcion_academico"]?></td>
                    <td id="campo"> <?php echo $data["campo_conocimiento"]?></td>
                    <td id="disciplina"> <?php echo $data["disciplina"]?></td>
                    <td id="subdisciplina"> <?php echo $data["subdisciplina"]?></td>
                    <td>

                        <form method="POST">
                        <a href="php/submit_wp.php?idusuario_general=<?php echo $data["idusuario_general"];
                        ?>" class="texto-verde negritas">WhatsApp</a>
                        <a id="submit_gm" href="#gm" class="texto-azul negritas">Gmail</a>
                        </form>
                    </td>
                </tr>

            <?php
                    }
                }

                 if ($result == 0) {
                    echo $message;
                    }
            ?>
            </table>
            </section>

            </div>
            </div>
        </div>

        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    </body>
    </html>