<?php
	include("conexion.php");

	$consulta_uci_labs = "SELECT * FROM uci_form_unis_cis";
	$ejecutarUciLabs = mysqli_query($connection, $consulta_uci_labs);

	while($fila = mysqli_fetch_array($ejecutarUciLabs)){
		echo "<option value = '".$fila['nombre_uni_ci']."'>".$fila['nombre_uni_ci']."</option>";
	}
?>