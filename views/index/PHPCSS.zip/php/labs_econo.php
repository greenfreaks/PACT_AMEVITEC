    <?php
        include "../index.php";
        $id_econo = $_GET["id_econo"];
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Somos la Agencia Mexicana de Vinculación Tecnológica, una asociación civil sin fines de lucro dedicada a promover, gestionar y capacitar la vinculación entre empresas y universidades.">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PACT</title>

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
        <link rel="stylesheet" href="../css/table_labs.css">


       <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <title>
        </title>
    </head>
    <body>

        <style type="text/css">
            #chooseTables{
                display: none;
            }
            .table_container, .searcher_container{
                display: none;
            }
        </style>
        <div class="content_container">
             <section id="labsEcono">
                            <?php 

                                //CONSULTA
                                $query_name = mysqli_query($connection, "SELECT * FROM uci_labs_econo uli INNER JOIN uci_form_unis_cis u ON uli.fk_econo_uni_ci = u.id WHERE uli.fk_econo_uni_ci = '$id_econo' LIMIT 1");

                                $result_name = mysqli_num_rows($query_name);

                                if($result_name > 0){
                                    while ($data = mysqli_fetch_array($query_name)){
                            ?>
                                    <h5 class="texto-marino">Laboratorios del área de economía</h5>
                                    <h6 class="negritas"> Institución:</h6 class="negritas">
                                    <h5 class="texto-azul negritas">
                                        <?php echo $data["nombre_uni_ci"]?>
                                    </h5>

                            <?php
                                    }
                                }
                            ?>
                </section>
            <section id="labsIng" class="lab_table">
                     <table class="table sticky">
                        <thead>
                            <tr class="tr">
                                <th>Laboratorio</th>
                                <th>Equipo</th>
                                <th>Servicio</th>
                                <th>Observaciones</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php 

                                //CONSULTA
                                $query = mysqli_query($connection, "SELECT * FROM uci_labs_econo uli INNER JOIN uci_form_unis_cis u ON uli.fk_econo_uni_ci = u.id WHERE uli.fk_econo_uni_ci = '$id_econo'");

                                $result = mysqli_num_rows($query);

                                if($result > 0){
                                    while ($data = mysqli_fetch_array($query)){
                            ?>
                                    <tr class="active-row">
                                        <td><?php echo $data["laboratorio"]?></td>
                                        <td class="col_nombre bold"><?php echo $data["equipo"]?></td>
                                        <td><?php echo $data["servicio"]?></td>
                                        <td class="more_with"><?php echo $data["descripcion"]?></td>
                                    </tr>

                            <?php
                                    }
                                }
                            ?>
                        </tbody>
                    </table>
                </section>

                <section>
                    <a class="btn" href="../">Regresar</a>
                </section>
        </div>

        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
           
       <script type="text/javascript">
            $(document).ready( function () {
        $('#table_unis_cis').DataTable();
    } );
        </script>
        
    </body>
    </html>