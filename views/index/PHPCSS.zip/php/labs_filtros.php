<?php 
                /*--------------------------------------------------------------------------------------------------------*/
                /*-----------------------------------------VARIABLES DE BÚSQUEDA------------------------------------------*/
                /*--------------------------------------------------------------------------------------------------------*/

                    $where= "";
                    $institucion = $_POST["institucion"];
                    $ambito = $_POST["ambito"];
                    $industria = $_POST["industria"];
                    $buscar_texto = $_POST["buscar_texto"];
                    $message = "<h5 class = 'bold'>No se encontraron resultados de su búsqueda</h5>";

                /*---------------------------------------------------------------------------------------------------------------------*/
                /*-----------------------------------------CONDICIONES-----------------------------------------------------------------*/
                /*---------------------------------------------------------------------------------------------------------------------*/

                    if ($institucion =="" && $ambito =="" && $industria =="" && $buscar_texto =="") {
                        $where = "";

                    }else{
                /*---------------------------------------------------------------------------------------------------------------------*/
                /*-----------------------------------------CONDICIONES FILTROS SOLOS---------------------------------------------------*/
                /*---------------------------------------------------------------------------------------------------------------------*/

                        if ($institucion !="" && $ambito =="" && $industria =="" && $buscar_texto =="") {
                            $where = "WHERE nombre_uni_ci = '$institucion'";
                        }

                        if ($institucion =="" && $ambito !="" && $industria =="" && $buscar_texto =="") {
                            $where = "WHERE ambito = '$ambito'";
                        }

                        if ($institucion =="" && $ambito =="" && $industria !="" && $buscar_texto =="") {
                            $where = "WHERE industria LIKE '%".$industria."%'";
                        }

                        if ($institucion =="" && $ambito =="" && $industria =="" && $buscar_texto !="") {
                            $where = "WHERE equipo LIKE '%".$buscar_texto."%' OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%'";
                        }

                /*------------------------------------------------------------------------------------------------------------------------------*/
                /*-----------------------------------------CONDICIONES BASADAS EN INSTITUCION---------------------------------------------------*/
                /*------------------------------------------------------------------------------------------------------------------------------*/
                        if ($institucion !="" && $ambito !="" && $industria =="" && $buscar_texto =="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND ambito = '$ambito'";
                        }

                        if ($institucion !="" && $ambito =="" && $industria !="" && $buscar_texto =="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND industria LIKE '%".$industria."%'";
                        }

                        if ($institucion !="" && $ambito =="" && $industria =="" && $buscar_texto !="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%'";
                        }

                        if ($institucion !="" && $ambito !="" && $industria !="" && $buscar_texto =="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND ambito = '$ambito' AND industria LIKE '%".$industria."%'";
                        }

                        if ($institucion !="" && $ambito !="" && $industria !="" && $buscar_texto !="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND ambito = '$ambito' AND industria LIKE '%".$industria."%'
                            AND equipo LIKE '%".$buscar_texto."%' OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%'";
                        }

                /*------------------------------------------------------------------------------------------------------------------------------*/
                /*-----------------------------------------CONDICIONES BASADAS EN ÁMBITO--------------------------------------------------------*/
                /*------------------------------------------------------------------------------------------------------------------------------*/
                        /*if ($institucion !="" && $ambito !="" && $industria =="" && $buscar_texto =="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND ambito = '$ambito'";
                        }*/

                        if ($institucion =="" && $ambito !="" && $industria !="" && $buscar_texto =="") {
                            $where = "WHERE ambito = '$ambito' AND industria LIKE '%".$industria."%'";
                        }

                        if ($institucion =="" && $ambito !="" && $industria =="" && $buscar_texto !="") {
                            $where = "WHERE ambito = '$ambito' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%'";
                        }

                        if ($institucion =="" && $ambito !="" && $industria !="" && $buscar_texto !="") {
                            $where = "WHERE ambito = '$ambito' AND industria LIKE '%".$industria."%' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%' ";
                        }

                /*------------------------------------------------------------------------------------------------------------------------------*/
                /*-----------------------------------------CONDICIONES BASADAS EN INDUSTRIA-----------------------------------------------------*/
                /*------------------------------------------------------------------------------------------------------------------------------*/
                        /*if ($institucion !="" && $ambito =="" && $industria !="" && $buscar_texto =="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND industria LIKE '%".$industria."%'";
                        }*/

                        if ($institucion =="" && $ambito !="" && $industria !="" && $buscar_texto =="") {
                            $where = "WHERE ambito = '$ambito' AND industria LIKE '%".$industria."%'";
                        }

                        if ($institucion =="" && $ambito =="" && $industria !="" && $buscar_texto !="") {
                            $where = "WHERE industria LIKE '%".$industria."%' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%'";
                        }

                        if ($institucion =="" && $ambito !="" && $industria !="" && $buscar_texto !="") {
                            $where = "WHERE ambito = '$ambito' AND industria LIKE '%".$industria."%' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%' ";
                        }
                /*------------------------------------------------------------------------------------------------------------------------------*/
                /*-----------------------------------------CONDICIONES BASADAS EN BUSCADOR------------------------------------------------------*/
                /*------------------------------------------------------------------------------------------------------------------------------*/
                        if ($institucion !="" && $ambito =="" && $industria =="" && $buscar_texto !="") {
                            $where = "WHERE nombre_uni_ci = '$institucion' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%";
                        }

                        if ($institucion =="" && $ambito !="" && $industria =="" && $buscar_texto !="") {
                            $where = "WHERE ambito = '$ambito' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%";
                        }

                        /*if ($institucion =="" && $ambito =="" && $industria !="" && $buscar_texto !="") {
                            $where = "WHERE industria LIKE '%".$industria."%' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%'";
                        }*/

                        if ($institucion =="" && $ambito !="" && $industria !="" && $buscar_texto !="") {
                            $where = "WHERE ambito = '$ambito' AND industria LIKE '%".$industria."%' AND equipo LIKE '%".$buscar_texto."%' 
                            OR servicio LIKE '%".$buscar_texto."%' OR descripcion LIKE '%".$buscar_texto."%' ";
                        }
                    }

                ?>